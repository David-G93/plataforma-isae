<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('teaching_teacher', function (Blueprint $table) {
            $table->id();

            $table->foreignId('teaching_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->foreignId('teacher_profile_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->timestamps();

            $table->unique([
                'teaching_id',
                'teacher_profile_id',
            ]);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('teaching_teacher');
    }
};